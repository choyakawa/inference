from .restful.restful_client import (  # noqa: F401
    RESTfulAudioModelHandle as AudioModelHandle,
)
from .restful.restful_client import (  # noqa: F401
    RESTfulChatModelHandle as ChatModelHandle,
)
from .restful.restful_client import (  # noqa: F401
    RESTfulEmbeddingModelHandle as EmbeddingModelHandle,
)
from .restful.restful_client import (  # noqa: F401
    RESTfulGenerateModelHandle as GenerateModelHandle,
)
from .restful.restful_client import (  # noqa: F401
    RESTfulImageModelHandle as ImageModelHandle,
)
